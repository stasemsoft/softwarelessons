﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PiratesVersusNinjas
{
    class Karakter
    {
        // Fields
        Random dobbelsteen;
        int levens;
        bool superwapenGebruikt;
        
        // Constructor
        public Karakter(Random spelDobbelsteen, int karakterLevens)
        {
            /*
             * STAP 3
             * Bij het aanmaken van een nieuw Karakter wordt deze
             * Constructor aangeroepen. Geef in deze constructor de
             * Fields 'levens', 'dobbelsteen' en 'superwapenGebruikt'
             * een waarde. De eerste 2 waardes krijg je als parameters
             * mee. Uiteraard is bij het aanmaken van een karakter het
             * superwapen nog niet gebruikt.
             */


        }

        // Methodes
        public int GeefLevens()
        {
            return levens;
        }

        public int ValAan()
        {
            /*
             * STAP 6
             * Als het karakter aanvalt, wordt de hoeveelheid schade die
             * hij doet bepaald met de dobbelsteen. Het minimum is 1 en
             * het maximum is 6. Retourneer deze waarde ipv de 0 die nu
             * geretourneerd wordt.
             */

            return 0;
        }

        public void OntvangSchade(int schade)
        {
            /* 
             * STAP 6
             * Het karakter verliest zoveel levens als er schade gedaan wordt.
             * Verminder de levens.
             */

        }

        public int GebruikSuperwapen()
        {
            /*
             * STAP 7
             * Er wordt gecontroleerd of het superwapen al gebruikt is.
             * Zo ja dan retourneert deze methode 0, zo nee dan retourneert
             * deze methode 9. Het geretourneerde cijfer is de hoeveelheid
             * schade die het superwapen doet.
             * Bij het aanroepen van deze methode wordt nu nog altijd 0
             * geretourneerd, dat is natuurlijk niet goed. Pas dit aan.
             */

            return 0;
        }
    }
}
