﻿namespace PiratesVersusNinjas
{
    partial class PiratesVersusNinjasForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.pbNinja = new System.Windows.Forms.PictureBox();
            this.pbPirate = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.progressPirateLevens = new System.Windows.Forms.ProgressBar();
            this.progressNinjaLevens = new System.Windows.Forms.ProgressBar();
            this.lblSchade = new System.Windows.Forms.Label();
            this.gbPirateWapens = new System.Windows.Forms.GroupBox();
            this.btnPirateWapen = new System.Windows.Forms.Button();
            this.btnPirateSuperwapen = new System.Windows.Forms.Button();
            this.gbNinjaWapens = new System.Windows.Forms.GroupBox();
            this.btnNinjaWapen = new System.Windows.Forms.Button();
            this.btnNinjaSuperwapen = new System.Windows.Forms.Button();
            this.gbNieuwSpel = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.nudLevens = new System.Windows.Forms.NumericUpDown();
            this.btnStart = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pbNinja)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbPirate)).BeginInit();
            this.gbPirateWapens.SuspendLayout();
            this.gbNinjaWapens.SuspendLayout();
            this.gbNieuwSpel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudLevens)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Copperplate Gothic Light", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 194);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(81, 21);
            this.label1.TabIndex = 1;
            this.label1.Text = "Pirate";
            // 
            // pbNinja
            // 
            this.pbNinja.Image = global::PiratesVersusNinjas.Properties.Resources.ninja;
            this.pbNinja.Location = new System.Drawing.Point(321, 12);
            this.pbNinja.Name = "pbNinja";
            this.pbNinja.Size = new System.Drawing.Size(120, 150);
            this.pbNinja.TabIndex = 2;
            this.pbNinja.TabStop = false;
            this.pbNinja.Visible = false;
            // 
            // pbPirate
            // 
            this.pbPirate.Image = global::PiratesVersusNinjas.Properties.Resources.pirate;
            this.pbPirate.Location = new System.Drawing.Point(12, 12);
            this.pbPirate.Name = "pbPirate";
            this.pbPirate.Size = new System.Drawing.Size(120, 150);
            this.pbPirate.TabIndex = 0;
            this.pbPirate.TabStop = false;
            this.pbPirate.Visible = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Jing Jing", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(366, 194);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(75, 25);
            this.label2.TabIndex = 3;
            this.label2.Text = "Ninja";
            // 
            // progressPirateLevens
            // 
            this.progressPirateLevens.Location = new System.Drawing.Point(12, 168);
            this.progressPirateLevens.Name = "progressPirateLevens";
            this.progressPirateLevens.Size = new System.Drawing.Size(120, 23);
            this.progressPirateLevens.TabIndex = 4;
            // 
            // progressNinjaLevens
            // 
            this.progressNinjaLevens.Location = new System.Drawing.Point(321, 168);
            this.progressNinjaLevens.Name = "progressNinjaLevens";
            this.progressNinjaLevens.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.progressNinjaLevens.RightToLeftLayout = true;
            this.progressNinjaLevens.Size = new System.Drawing.Size(120, 23);
            this.progressNinjaLevens.TabIndex = 5;
            // 
            // lblSchade
            // 
            this.lblSchade.AutoSize = true;
            this.lblSchade.Font = new System.Drawing.Font("Consolas", 72F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSchade.ForeColor = System.Drawing.Color.Red;
            this.lblSchade.Location = new System.Drawing.Point(183, 123);
            this.lblSchade.Name = "lblSchade";
            this.lblSchade.Size = new System.Drawing.Size(0, 112);
            this.lblSchade.TabIndex = 8;
            // 
            // gbPirateWapens
            // 
            this.gbPirateWapens.Controls.Add(this.btnPirateWapen);
            this.gbPirateWapens.Controls.Add(this.btnPirateSuperwapen);
            this.gbPirateWapens.Enabled = false;
            this.gbPirateWapens.Location = new System.Drawing.Point(12, 235);
            this.gbPirateWapens.Name = "gbPirateWapens";
            this.gbPirateWapens.Size = new System.Drawing.Size(120, 110);
            this.gbPirateWapens.TabIndex = 9;
            this.gbPirateWapens.TabStop = false;
            this.gbPirateWapens.Text = "Wapens";
            // 
            // btnPirateWapen
            // 
            this.btnPirateWapen.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPirateWapen.Location = new System.Drawing.Point(6, 21);
            this.btnPirateWapen.Name = "btnPirateWapen";
            this.btnPirateWapen.Size = new System.Drawing.Size(108, 35);
            this.btnPirateWapen.TabIndex = 8;
            this.btnPirateWapen.Text = "Sabel";
            this.btnPirateWapen.UseVisualStyleBackColor = true;
            this.btnPirateWapen.Click += new System.EventHandler(this.btnPirateWapen_Click);
            // 
            // btnPirateSuperwapen
            // 
            this.btnPirateSuperwapen.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPirateSuperwapen.Location = new System.Drawing.Point(6, 62);
            this.btnPirateSuperwapen.Name = "btnPirateSuperwapen";
            this.btnPirateSuperwapen.Size = new System.Drawing.Size(108, 35);
            this.btnPirateSuperwapen.TabIndex = 7;
            this.btnPirateSuperwapen.Text = "Pistool";
            this.btnPirateSuperwapen.UseVisualStyleBackColor = true;
            this.btnPirateSuperwapen.Click += new System.EventHandler(this.btnPirateSuperwapen_Click);
            // 
            // gbNinjaWapens
            // 
            this.gbNinjaWapens.Controls.Add(this.btnNinjaWapen);
            this.gbNinjaWapens.Controls.Add(this.btnNinjaSuperwapen);
            this.gbNinjaWapens.Enabled = false;
            this.gbNinjaWapens.Location = new System.Drawing.Point(321, 235);
            this.gbNinjaWapens.Name = "gbNinjaWapens";
            this.gbNinjaWapens.Size = new System.Drawing.Size(120, 110);
            this.gbNinjaWapens.TabIndex = 10;
            this.gbNinjaWapens.TabStop = false;
            this.gbNinjaWapens.Text = "Wapens";
            // 
            // btnNinjaWapen
            // 
            this.btnNinjaWapen.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNinjaWapen.Location = new System.Drawing.Point(6, 21);
            this.btnNinjaWapen.Name = "btnNinjaWapen";
            this.btnNinjaWapen.Size = new System.Drawing.Size(108, 35);
            this.btnNinjaWapen.TabIndex = 8;
            this.btnNinjaWapen.Text = "Zwaard";
            this.btnNinjaWapen.UseVisualStyleBackColor = true;
            this.btnNinjaWapen.Click += new System.EventHandler(this.btnNinjaWapen_Click);
            // 
            // btnNinjaSuperwapen
            // 
            this.btnNinjaSuperwapen.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNinjaSuperwapen.Location = new System.Drawing.Point(6, 62);
            this.btnNinjaSuperwapen.Name = "btnNinjaSuperwapen";
            this.btnNinjaSuperwapen.Size = new System.Drawing.Size(108, 35);
            this.btnNinjaSuperwapen.TabIndex = 7;
            this.btnNinjaSuperwapen.Text = "Shuriken";
            this.btnNinjaSuperwapen.UseVisualStyleBackColor = true;
            this.btnNinjaSuperwapen.Click += new System.EventHandler(this.btnNinjaSuperwapen_Click);
            // 
            // gbNieuwSpel
            // 
            this.gbNieuwSpel.Controls.Add(this.label4);
            this.gbNieuwSpel.Controls.Add(this.nudLevens);
            this.gbNieuwSpel.Controls.Add(this.btnStart);
            this.gbNieuwSpel.Location = new System.Drawing.Point(138, 12);
            this.gbNieuwSpel.Name = "gbNieuwSpel";
            this.gbNieuwSpel.Size = new System.Drawing.Size(177, 96);
            this.gbNieuwSpel.TabIndex = 14;
            this.gbNieuwSpel.TabStop = false;
            this.gbNieuwSpel.Text = "Nieuw spel";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(36, 21);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(42, 13);
            this.label4.TabIndex = 16;
            this.label4.Text = "Levens";
            // 
            // nudLevens
            // 
            this.nudLevens.Increment = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.nudLevens.Location = new System.Drawing.Point(84, 19);
            this.nudLevens.Minimum = new decimal(new int[] {
            25,
            0,
            0,
            0});
            this.nudLevens.Name = "nudLevens";
            this.nudLevens.Size = new System.Drawing.Size(61, 20);
            this.nudLevens.TabIndex = 15;
            this.nudLevens.Value = new decimal(new int[] {
            25,
            0,
            0,
            0});
            // 
            // btnStart
            // 
            this.btnStart.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnStart.Location = new System.Drawing.Point(39, 45);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(106, 45);
            this.btnStart.TabIndex = 14;
            this.btnStart.Text = "Start!";
            this.btnStart.UseVisualStyleBackColor = true;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // PiratesVersusNinjasForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(453, 357);
            this.Controls.Add(this.gbNieuwSpel);
            this.Controls.Add(this.gbNinjaWapens);
            this.Controls.Add(this.gbPirateWapens);
            this.Controls.Add(this.lblSchade);
            this.Controls.Add(this.progressNinjaLevens);
            this.Controls.Add(this.progressPirateLevens);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.pbNinja);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pbPirate);
            this.Name = "PiratesVersusNinjasForm";
            this.Text = "Pirates versus Ninjas";
            ((System.ComponentModel.ISupportInitialize)(this.pbNinja)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbPirate)).EndInit();
            this.gbPirateWapens.ResumeLayout(false);
            this.gbNinjaWapens.ResumeLayout(false);
            this.gbNieuwSpel.ResumeLayout(false);
            this.gbNieuwSpel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudLevens)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pbPirate;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pbNinja;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ProgressBar progressPirateLevens;
        private System.Windows.Forms.ProgressBar progressNinjaLevens;
        private System.Windows.Forms.Label lblSchade;
        private System.Windows.Forms.GroupBox gbPirateWapens;
        private System.Windows.Forms.Button btnPirateWapen;
        private System.Windows.Forms.Button btnPirateSuperwapen;
        private System.Windows.Forms.GroupBox gbNinjaWapens;
        private System.Windows.Forms.Button btnNinjaWapen;
        private System.Windows.Forms.Button btnNinjaSuperwapen;
        private System.Windows.Forms.GroupBox gbNieuwSpel;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.NumericUpDown nudLevens;
        private System.Windows.Forms.Button btnStart;
    }
}

