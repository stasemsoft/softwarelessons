﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PiratesVersusNinjas
{
    public partial class PiratesVersusNinjasForm : Form
    {
        // Fields
        Random dobbelsteen;
        Karakter piraat;
        Karakter ninja;

        // Constructor
        public PiratesVersusNinjasForm()
        {
            InitializeComponent();
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            gbNieuwSpel.Enabled = false;

            /*
             * STAP 1
             * Het spel maakt gebruik van een dobbelsteen. Maak dus
             * een nieuwe instantie aan van de klasse Random. Dit is
             * gelijk aan hoe je dit bij OIS geleerd hebt.
             */




            /*
             * STAP 2
             * Het spel gaat over 2 karakters, een piraat en een ninja.
             * Maak twee instanties van de klasse Karakter aan, de eerste
             * wordt opgeslagen in het Field "piraat" en de tweede in
             * het Field "ninja".
             */






            if (piraat != null)
            {
                progressPirateLevens.Maximum = piraat.GeefLevens();
                progressPirateLevens.Value = progressPirateLevens.Maximum;
            }

            if (ninja != null)
            {
                progressNinjaLevens.Maximum = ninja.GeefLevens();
                progressNinjaLevens.Value = progressNinjaLevens.Maximum;
            }

            StartSpel();
        }

        private void StartSpel()
        {
            // Pirate en Ninja komen in beeld.
            pbPirate.Visible = true;
            pbNinja.Visible = true;

            // rol een dobbelsteen met alleen 0 en 1.
            int startKarakterRol = dobbelsteen.Next(2);
            if (startKarakterRol == 0)
            {
                // Als het 0 is mag Pirate beginnen...
                gbPirateWapens.Enabled = true;
            }
            else
            {
                // en anders Ninja.
                gbNinjaWapens.Enabled = true;
            }
        }

        private void VerversSpelstatus(int schade)
        {
            // De hoeveelheid schade wordt weergegeven op het scherm.
            lblSchade.Text = Convert.ToString(schade);

            int pirateLevens = piraat.GeefLevens();
            // Als Pirate nog levens heeft...
            if (pirateLevens > 0)
            {
                // geef dan het aantal levens van Pirate weer op het scherm...
                progressPirateLevens.Value = pirateLevens;
            }
            else
            {
                // en anders heeft Ninja gewonnen!
                progressPirateLevens.Value = 0;
                pbPirate.Visible = false;
                NinjaGewonnen();
            }

            int ninjaLevens = ninja.GeefLevens();
            // Als Ninja nog levens heeft...
            if (ninjaLevens > 0)
            {
                // geef dan het aantal levens van Ninja weer op het scherm...
                progressNinjaLevens.Value = ninjaLevens;
            }
            else
            {
                // en anders heeft Pirate gewonnen!
                progressNinjaLevens.Value = 0;
                pbNinja.Visible = false;
                PirateGewonnen();
            }
        }

        private void btnPirateWapen_Click(object sender, EventArgs e)
        {
            /*
             * STAP 4
             * Pirate valt aan, verwerk de schade. Daarna wisselt de beurt.
             * Vergeet als laatste niet de spelstatus te verversen.
             */


        }

        private void btnNinjaWapen_Click(object sender, EventArgs e)
        {
            /*
             * STAP 4
             * Ninja valt aan, verwerk de schade. Daarna wisselt de beurt.
             * Vergeet als laatste niet de spelstatus te verversen.
             */


        }

        private void WisselBeurt()
        {
            /*
             * STAP 5
             * Als de GroupBox 'gbPirateWapens' ingeschakeld is (Enabled), dan
             * was het nu dus de beurt van Pirate en moet het de beurt van
             * Ninja gaan worden. Schakel daartoe de GroupBox 'gbPirateWapens'
             * uit, en de GroupBox 'gbNinjaWapens' in. In het andere geval is
             * het precies anders om, de beurt van Ninja wordt nu de beurt
             * van Pirate.
             */


        }

        private void btnPirateSuperwapen_Click(object sender, EventArgs e)
        {
            /*
             * STAP 7
             * Pirate valt aan met zijn superwapen, verwerk de schade.
             * Daarna wisselt de beurt.
             * Vergeet wederom niet de spelstatus te verversen.
             */


        }

        private void btnNinjaSuperwapen_Click(object sender, EventArgs e)
        {
            /*
             * STAP 7
             * Ninja valt aan met zijn superwapen, verwerk de schade.
             * Daarna wisselt de beurt.
             * Vergeet wederom niet de spelstatus te verversen.
             */


        }

        

        private void StopSpel()
        {
            gbNieuwSpel.Enabled = true;
            gbPirateWapens.Enabled = false;
            gbNinjaWapens.Enabled = false;
            lblSchade.Text = "";
        }

        private void PirateGewonnen()
        {
            /*
             * STAP 8
             * Pirate heeft gewonnen! Stop het spel en laat een MessageBox zien
             * met een leuk bericht over de winst van Pirate.
             */


        }

        private void NinjaGewonnen()
        {
            /*
             * STAP 8
             * Ninja heeft gewonnen! Stop het spel en laat een MessageBox zien
             * met een leuk bericht over de winst van Ninja.
             */


        }
    }
}
