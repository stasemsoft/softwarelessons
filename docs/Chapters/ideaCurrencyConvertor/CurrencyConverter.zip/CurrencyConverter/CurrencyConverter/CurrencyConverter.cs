﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CurrencyConverter
{
    class CurrencyConverter
    {
        private string name;
        private Decimal rate;

        public CurrencyConverter(string valutaName, Decimal exchangeRate)
        {
            name = valutaName;
            rate = exchangeRate;
        }

        public Decimal Convert(Decimal euros)
        {
            return rate * euros;
        }

        public override string ToString()
        {
            return name;
        }
    }
}
