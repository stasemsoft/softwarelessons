﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CurrencyConverter
{
    public partial class ConverterForm: Form
    {
        public ConverterForm()
        {
            InitializeComponent();
            cbValuta.Items.Add(new CurrencyConverter("Yen", 1.73m));
            cbValuta.Items.Add(new CurrencyConverter("Dollar", 0.72m));
            cbValuta.Items.Add(new CurrencyConverter("GBP", 1.36m));
            cbValuta.Items.Add(new CurrencyConverter("Bitcoin", 1234m));
            cbValuta.Items.Add(new CurrencyConverter("Gulden", 2.21m));
        }

        private void btnConvert_Click(object sender, EventArgs e)
        {
            CurrencyConverter selected = cbValuta.SelectedItem as CurrencyConverter;
            if (selected == null)
            {
                MessageBox.Show("selecteer aub een valuta");
            }
            else
            {
                Decimal value = nudValue.Value;
                lblResult.Text = selected.Convert(value).ToString();
            }
        }
    }
}
